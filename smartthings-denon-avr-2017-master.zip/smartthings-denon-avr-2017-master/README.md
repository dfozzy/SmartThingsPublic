# Denon 2017 AVR Support for Smartthings

Smartthings SmartApp and Device Handler to support 2017 Denon AVR with HEOS enabled.

Tested on my X6400H, but should work on S730H, X1400H, S930H, X2400H, X3400H and X4400H as well. May also work on other models that are supported by the Denon AVR Remote app.
